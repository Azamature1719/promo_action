from django.contrib import admin
from .models import Prize, Participant, Promo, Result

admin.site.register(Prize)
admin.site.register(Participant)
admin.site.register(Promo)
admin.site.register(Result)
