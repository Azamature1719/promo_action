from django.db import models

class Prize(models.Model):
    description = models.TextField()

    def __str__(self):
        return self.description

class Participant(models.Model):
    name = models.CharField(max_length=200)

    def __str__(self):
        return self.name

class Promo(models.Model):
    name = models.CharField(max_length=200)
    description = models.TextField()
    prizes = models.ManyToManyField(Prize)
    participants = models.ManyToManyField(Participant)

    def __str__(self):
        return self.name

class Result(models.Model):
    winner = models.ForeignKey(Participant, on_delete=models.CASCADE)
    prize = models.ForeignKey(Prize, on_delete=models.CASCADE)
