from rest_framework import serializers
from .models import Prize, Participant, Promo, Result

class PromoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Promo
        fields = ['id', 'name', 'description']

class PromoSerializerRead(serializers.ModelSerializer):
    class Meta:
        model = Promo
        depth = 1
        fields = ['id', 'name', 'description', 'prizes', 'participants']

class PromoSerializerUpdate(serializers.ModelSerializer):
    class Meta:
        model = Promo
        read_only_fields = ['name']
        fields = ['name', 'description']

class ResultSerializer(serializers.ModelSerializer):
    class Meta:
        model = Result
        depth = 1

class PrizeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Prize
        fields = ['description']

class ParticipantSerializer(serializers.ModelSerializer):
    class Meta:
        model = Participant
        fields = ['name']
