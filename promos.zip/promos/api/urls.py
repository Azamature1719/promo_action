from django.urls import path

from . import views

urlpatterns = [
    path('promo/', views.PromoList.as_view()),
    path('promo/<int:pk>', views.PromoDetail.as_view()),
    path('promo/<int:pk>/raffle', views.Raffle.as_view()),
]
