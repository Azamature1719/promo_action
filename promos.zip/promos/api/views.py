from rest_framework import generics
from . import serializers
from .models import Prize, Participant, Promo, Result

class PromoList(generics.ListCreateAPIView):
    queryset = Promo.objects.all()
    serializer_class = serializers.PromoSerializer

    def perform_create(self, serializer):
        serializer.save()

class PromoDetail(generics.RetrieveUpdateAPIView):
    if("read"):
        queryset = Promo.objects.all()
        serializer_class = serializers.PromoSerializerUpdate
    else:
        queryset = Promo.objects.all()
        serializer_class = serializers.PromoSerializerRead

class Raffle(generics.RetrieveUpdateAPIView):
    serializer_class = serializers.ResultSerializer

    def perform_create(self, serializer):
        serializer.save()
